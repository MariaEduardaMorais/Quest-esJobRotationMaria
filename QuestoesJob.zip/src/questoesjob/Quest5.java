/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questoesjob;

/**
 *
 * @author meram
 */
public class Quest5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Quest5Class p = new Quest5Class();

        p.empilhar("FÁCIL");
        p.empilhar("MUITO");
        p.empilhar("É");
        p.empilhar("EXERCÍCIO");
        p.empilhar("ESTE");

        System.out.println("_________________");
        while (p.pilhaVazia() == false) {
            System.out.println(p.desempilhar());
        }
    }
}
