/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questoesjob;

import java.util.Scanner;

/**
 *
 * @author meram
 */
public class Quest3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        double[] VetMes = new double[30];
        double media = 0, soma = 0;
        int contZ = 0;
        int contM = 0;

        System.out.println("Insira os faturamentos do mês: ");
        for (int i = 0; i < 30; i++) {
            System.out.println("==== Dia " + (i + 1) + " ====");
            System.out.print("VALOR: ");
            VetMes[i] = scan.nextDouble();
            soma = soma + VetMes[i];
            media = (soma / 21);
            if (VetMes[i] > media) {
                contM++;
            }
            if (VetMes[i] == 0) {
                contZ++;
            }
        }
        for (int i = 1; i < VetMes.length; i++) {//maior
            for (int j = 0; j < i; j++) {
                if (VetMes[i] > VetMes[j]) { // compara os nÃºmeros dentro do array
                    double a = VetMes[i];
                    VetMes[i] = VetMes[j];
                    VetMes[j] = a;
                }
            }
        }
        System.out.println("Menor valor de faturamento do mês: " + VetMes[20] + "\nVezes em que houve 0.0 de faturamento: " + contZ); // saÃ­da / dias do mês - dias que foram 0 de faturamento
        System.out.println("Maior valor de faturamento do mês: " + VetMes[0]); // saÃ­da
        System.out.println("A média de faturamento do mês foi de: " + media + "\nO número de vezes que o faturamento diário foi maior que a média é : " + contM);

        scan.close();
    }
}
