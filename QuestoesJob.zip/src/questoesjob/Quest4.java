/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questoesjob;

import java.util.Scanner;

/**
 *
 * @author meram
 */
public class Quest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        double fatSP, fatRJ, fatMG, fatES, fatO, fatTotal;
        double SP, RJ, MG, ES, Outros;

        System.out.println("Insira o valor de faturamento de SP: ");
        fatSP = scan.nextDouble();
        System.out.println("Insira o valor de faturamento do RJ: ");
        fatRJ = scan.nextDouble();
        System.out.println("Insira o valor de faturamento de MG: ");
        fatMG = scan.nextDouble();
        System.out.println("Insira o valor de faturamento de ES: ");
        fatES = scan.nextDouble();
        System.out.println("Insira o valor de faturamento dos outros estados no geral: ");
        fatO = scan.nextDouble();

        fatTotal = fatSP + fatRJ + fatMG + fatES + fatO;

        //cáculo da porcentagem --> ((estado/faturamentoTotal)*100)
        System.out.println("SP: ");
        SP = CalcularPorcent(fatSP, fatTotal);
        System.out.println("RJ: ");
        RJ = CalcularPorcent(fatRJ, fatTotal);
        System.out.println("MG: ");
        MG = CalcularPorcent(fatMG, fatTotal);
        System.out.println("ES: ");
        ES = CalcularPorcent(fatES, fatTotal);
        System.out.println("Outros estados: ");
        Outros= CalcularPorcent(fatO, fatTotal);

        System.out.println("O total do faturamento foi: R$" + fatTotal);

    }
    
    public static double CalcularPorcent(double valorEstado, double fatTotal){
        double total;
        total =  ((valorEstado/fatTotal)*100);
        System.out.println(total + "%" );
        return total;
    }
}
