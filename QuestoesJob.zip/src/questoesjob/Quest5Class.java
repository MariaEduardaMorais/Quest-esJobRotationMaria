/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questoesjob;

/**
 *
 * @author meram
 */
public class Quest5Class {
    public String[] pilha;
    public int posicaoPilha;
    public String y = "";
    public String aux;

    public Quest5Class() {
        this.posicaoPilha = -1;
        this.pilha = new String[100];
    }

    public boolean pilhaVazia() {
        return this.posicaoPilha == -1;
    }

    public int tamanho() {

        if (this.pilhaVazia()) {
            return 0;
        }
        return this.posicaoPilha + 1;
    }

    public Object exibeUltimoValor() {

        if (this.pilhaVazia()) {
            return null;
        }
        return this.pilha[this.posicaoPilha];
    }

    public String empilhar(String valor) {
        if (this.posicaoPilha < this.pilha.length - 1) {
            this.pilha[++posicaoPilha] = valor;
        }
        String contrario = "";
        for (int i = (valor.length() - 1); i >= 0; i--) {
            contrario = contrario + valor.charAt(i);
        }
        System.out.println(contrario);
        return contrario;
    }

    public Object desempilhar() {
        if (pilhaVazia()) {
            return null;
        }
        return this.pilha[this.posicaoPilha--];
    }
}


