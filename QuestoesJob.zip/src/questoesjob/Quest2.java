/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questoesjob;

import java.util.Scanner;

/**
 *
 * @author meram
 */
public class Quest2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        int num;
        int elementos;
        int aux = 0;

        System.out.println("Insira a quantidade de elementos desejados: ");
        elementos = scan.nextInt();

        int Fibonacci[] = new int[elementos];
        Fibonacci[0] = 0;
        Fibonacci[1] = 1;

        System.out.println("Insira o número que vamos analisar se está dentro da sequência de Fibonacci: ");
        num = scan.nextInt();

        for (int i = 2; i < elementos; ++i) {
            Fibonacci[i] = Fibonacci[i - 1] + Fibonacci[i - 2];
            if (Fibonacci[i] == num) {
                aux = Fibonacci[i];
            }
        }
        System.out.println("Esta é a sequência de Fibonacci com " + elementos + " elementos.");
        for (int j = 0; j < elementos; j++) {
            System.out.print(Fibonacci[j] + " ");
        }

        if (aux == num) {
            System.out.println("\nO número " + num + " está dentro da sequência de Fibonacci com " + elementos + " elementos.");
        } else if (aux != num) {
            System.out.println("\nO número " + num + " não está dentro da sequência de Fibonacci com " + elementos + " elementos.");
        }
    }
}
